import React, { createContext, useContext, useState, useEffect } from 'react';
import { MenuItem, CartItem, Order, OrderStatus, InventoryItem, UserRole, ServingStyle, DeliveryInfo, MenuOption, Ingredient, UserCoupon, User } from '../types';
import { MOCK_MENU, INITIAL_INVENTORY, STYLE_PRICES, RECIPES, INGREDIENTS, COUPON_THRESHOLD, LOYALTY_COUPON } from '../constants';
import { useAuth } from './AuthContext';
import { db, getScopedCollection, getPublicCollection, getScopedProfilePath } from '../firebase';
import { 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  doc, 
  query, 
  where, 
  orderBy,
  increment,
  writeBatch,
  getDoc,
  setDoc,
  arrayUnion,
  collection
} from 'firebase/firestore';

interface DataContextType {
  menu: MenuItem[];
  ingredients: Ingredient[];
  cart: CartItem[];
  inventory: InventoryItem[];
  orders: Order[];
  customers: User[];
  addToCart: (cartItem: Omit<CartItem, 'notes'>) => { success: boolean; message: string };
  removeFromCart: (index: number) => void;
  clearCart: () => void;
  placeOrder: (deliveryInfo: DeliveryInfo, usedCoupon?: UserCoupon) => Promise<void>;
  updateInventory: (ingredientId: string, delta: number) => Promise<void>;
  getMenuStock: (menuId: string) => number;
  updateMenuItemImage: (menuItemId: string, newImageUrl: string) => Promise<void>;
  updateMenuItem: (menuItemId: string, data: Partial<MenuItem>) => Promise<void>;
  deleteMenuItem: (menuItemId: string) => Promise<void>;
  addMenuItem: (item: Omit<MenuItem, 'id'>) => Promise<void>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  issueCoupon: (userId: string, discountPercent: number) => Promise<void>;
  getUserOrders: () => Order[];
  getAllOrders: () => Order[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>(INGREDIENTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<User[]>([]);

  const publicMenuRef = getPublicCollection('menu_items');
  const publicInventoryRef = getPublicCollection('inventory');
  const publicOrdersRef = getPublicCollection('orders');

  // 1. Fetch Menu & Inventory (Shared)
  useEffect(() => {
    if (!user) return;

    // Sync Menu
    const unsubMenu = onSnapshot(publicMenuRef, async (snapshot) => {
      const currentItems = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MenuItem));
      if (snapshot.empty) {
         const batch = writeBatch(db);
         MOCK_MENU.forEach(item => batch.set(doc(publicMenuRef, item.id), item));
         await batch.commit();
         return; 
      }
      setMenu(currentItems);
    });

    // Sync Inventory
    const unsubInventory = onSnapshot(publicInventoryRef, async (snapshot) => {
      const invData = snapshot.docs.map(doc => ({ ingredientId: doc.id, ...doc.data() } as InventoryItem));
      if (invData.length < INGREDIENTS.length) {
          const batch = writeBatch(db);
          INITIAL_INVENTORY.forEach(item => {
              if (!invData.find(i => i.ingredientId === item.ingredientId)) {
                  batch.set(doc(publicInventoryRef, item.ingredientId), item);
              }
          });
          if(invData.length === 0) await batch.commit();
      }
      setInventory(invData);
    });

    return () => { unsubMenu(); unsubInventory(); };
  }, [user]);

  // 2. Fetch Orders
  useEffect(() => {
    if (!user) {
      setOrders([]);
      return;
    }

    let q;
    if (user.role === UserRole.STAFF) {
      q = query(publicOrdersRef, orderBy('createdAt', 'desc'));
    } else {
      q = query(publicOrdersRef, where('userId', '==', user.id));
    }

    const unsubOrders = onSnapshot(q, (snapshot) => {
      let orderData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      if (user.role !== UserRole.STAFF) {
          orderData = orderData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      setOrders(orderData);
    });

    return () => unsubOrders();
  }, [user]);

  // 3. Fetch Customers (Staff Only)
  useEffect(() => {
      if (user?.role === UserRole.STAFF) {
          const publicUsersRef = getPublicCollection('users_directory');
          const unsub = onSnapshot(publicUsersRef, (snap) => {
              setCustomers(snap.docs.map(d => ({id: d.id, ...d.data()} as User)));
          });
          return () => unsub();
      }
  }, [user]);

  const getMenuStock = (menuId: string): number => {
      const recipe = RECIPES[menuId];
      if (!recipe) return 0;
      let minServings = 9999;
      recipe.forEach(comp => {
          const invItem = inventory.find(i => i.ingredientId === comp.ingredientId);
          const stock = invItem ? invItem.quantity : 0;
          const servings = Math.floor(stock / comp.quantity);
          if (servings < minServings) minServings = servings;
      });
      return minServings;
  };

  const addToCart = (newItem: Omit<CartItem, 'notes'>) => {
    // Basic stock check for the *entire* customized set
    // Note: The UI Modal already does a robust check, this is a safety net
    let isStockOk = true;
    if (newItem.ingredientsPerSet) {
        newItem.ingredientsPerSet.forEach(req => {
            const totalReq = req.qty * newItem.quantity;
            const invItem = inventory.find(i => i.ingredientId === req.id);
            if (!invItem || invItem.quantity < totalReq) isStockOk = false;
        });
    }

    if (!isStockOk) {
      return { success: false, message: `재고가 부족하여 담을 수 없습니다.` };
    }

    setCart(prev => [...prev, newItem as CartItem]);
    return { success: true, message: '장바구니에 담았습니다.' };
  };

  const removeFromCart = (index: number) => {
      setCart(prev => prev.filter((_, i) => i !== index));
  };
  
  const clearCart = () => setCart([]);

  const placeOrder = async (deliveryInfo: DeliveryInfo, usedCoupon?: UserCoupon) => {
    if (!user) return;

    const total = cart.reduce((sum, item) => {
        const basePrice = item.menuItem.price;
        const stylePrice = STYLE_PRICES[item.style];
        const extraPrice = item.extraPricePerSet || 0;
        return sum + ((basePrice + stylePrice + extraPrice) * item.quantity);
    }, 0);

    let discountAmount = 0;
    if (usedCoupon) {
        discountAmount = total * (usedCoupon.discountPercent / 100);
    }
    const finalTotal = total - discountAmount;

    const newOrder: any = {
      userId: user.id,
      userName: user.name,
      items: [...cart],
      total,
      discountAmount,
      finalTotal,
      status: OrderStatus.CREATED,
      statusHistory: [{ status: OrderStatus.CREATED, timestamp: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
      deliveryInfo
    };

    const batch = writeBatch(db);
    const orderRef = doc(publicOrdersRef);
    batch.set(orderRef, newOrder);

    // Deduct Ingredients Logic
    cart.forEach(cItem => {
        if (cItem.ingredientsPerSet) {
            cItem.ingredientsPerSet.forEach(req => {
                const totalDeduct = req.qty * cItem.quantity;
                if (totalDeduct > 0) {
                    const invRef = doc(publicInventoryRef, req.id);
                    batch.update(invRef, { quantity: increment(-totalDeduct) });
                }
            });
        }
    });

    // Mark Coupon Used
    if (usedCoupon) {
         const profilePath = getScopedProfilePath(user.id);
         const userRef = doc(db, profilePath);
         const updatedCoupons = (user.coupons || []).filter(c => c.id !== usedCoupon.id);
         batch.update(userRef, { coupons: updatedCoupons });
    }
    
    // Update User Stats
    const publicUserRef = doc(getPublicCollection('users_directory'), user.id);
    batch.set(publicUserRef, { 
        id: user.id,
        name: user.name,
        email: user.email,
        completedOrders: increment(1) 
    }, { merge: true });

    await batch.commit();
    clearCart();
  };

  const updateInventory = async (ingredientId: string, delta: number) => { 
      if(!user) return; 
      const ref = doc(publicInventoryRef, ingredientId); 
      const s = await getDoc(ref);
      if (s.exists()) {
          const currentQty = s.data().quantity || 0;
          if (currentQty + delta < 0) return;
          await updateDoc(ref, { quantity: increment(delta) });
      } else if (delta > 0) {
          await setDoc(ref, { ingredientId, quantity: delta });
      }
  };

  const updateOrderStatus = async (orderId: string, status: OrderStatus) => { 
      if(!user) return; 
      const orderRef = doc(publicOrdersRef, orderId);
      await updateDoc(orderRef, { 
          status,
          statusHistory: arrayUnion({ status, timestamp: new Date().toISOString() })
      }); 
  };

  const issueCoupon = async (targetUserId: string, discountPercent: number) => {
      const profilePath = getScopedProfilePath(targetUserId);
      const userRef = doc(db, profilePath);
      
      const newCoupon: UserCoupon = {
          id: Math.random().toString(36).substr(2, 9),
          code: `STAFF-${discountPercent}`,
          name: `특별 ${discountPercent}% 할인 쿠폰`,
          discountPercent,
          used: false,
          createdAt: new Date().toISOString()
      };

      await updateDoc(userRef, {
          coupons: arrayUnion(newCoupon)
      });
  };

  // CRUD Wrappers
  const updateMenuItemImage = async (id: string, url: string) => updateDoc(doc(publicMenuRef, id), { image: url });
  const updateMenuItem = async (id: string, d: Partial<MenuItem>) => updateDoc(doc(publicMenuRef, id), d);
  const deleteMenuItem = async (id: string) => deleteDoc(doc(publicMenuRef, id));
  const addMenuItem = async (item: Omit<MenuItem, 'id'>) => {
    await addDoc(publicMenuRef, item);
  };

  return (
    <DataContext.Provider value={{
      menu, ingredients, cart, inventory, orders, customers,
      addToCart, removeFromCart, clearCart, placeOrder,
      updateInventory, getMenuStock,
      updateMenuItemImage, updateMenuItem, deleteMenuItem, addMenuItem, 
      updateOrderStatus, issueCoupon,
      getUserOrders: () => orders, getAllOrders: () => orders
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
};
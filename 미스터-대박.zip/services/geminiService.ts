// geminiService.tsx
import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import { MenuItem, VoiceIntent, IntentType } from '../types';
import { INGREDIENTS, STYLE_DESCRIPTIONS } from '../constants';

const getApiKey = () => {
  try {
    if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
      return process.env.API_KEY;
    }
  } catch (e) { }
  return '';
};

const API_KEY = getApiKey();
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const isGeminiConfigured = (): boolean => {
  return !!API_KEY;
};

export const createChatSession = (menuItems: MenuItem[]) => {
  if (!isGeminiConfigured()) return null;

  const menuContext = menuItems.map(m => `- ${m.name}: ${m.description}`).join("\n");

  return ai.chats.create({
    model: "gemini-2.5-flash",
    config: {
      systemInstruction: `
        당신은 '미스터 대박'의 AI 웨이터입니다. 
        사용자의 말을 듣고 메뉴를 추천하거나, 선택된 메뉴의 옵션을 조정하는 것을 도와줍니다.
        
        메뉴 목록:
        ${menuContext}

        답변 규칙:
        1. 친절하고 자연스러운 한국어로 대화하세요.
        2. 사용자가 메뉴를 수정하거나 주문하려는 의도를 보이면, 직접 처리하지 말고 "네, 반영해 드렸습니다." 또는 "주문화면을 갱신했습니다." 라고 짧게 답하세요.
        3. 추천을 요청하면 메뉴 중 하나를 골라 이유와 함께 권유하세요.
     `
    }
  });
};

export const sendChatMessage = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "죄송합니다. 다시 말씀해 주세요.";
  } catch (error) {
    console.error("Chat Error:", error);
    return "오류가 발생했습니다.";
  }
};

/**
 * Parses user input (voice or text) into a structured Intent for the Chatbot State Machine.
 */
export const parseVoiceCommand = async (
  transcript: string,
  menuItems: MenuItem[]
): Promise<VoiceIntent> => {
  if (!isGeminiConfigured()) return { type: IntentType.UNKNOWN };

  const menuNames = menuItems.map(m => m.name).join(", ");
  const ingredientNames = INGREDIENTS.map(i => `${i.name} (${i.id})`).join(", ");
  const styles = "Simple, Grand, Deluxe";

  const prompt = `
    Analyze the user's request for a restaurant chatbot.
    
    Context:
    - Menus: ${menuNames}
    - Ingredients: ${ingredientNames}
    - Styles: ${styles}

    Identify the Intent:
    1. RECOMMEND: User asks for suggestions (e.g., "What is good?", "I want something romantic").
    2. SELECT_MENU: User picks a specific main menu (e.g., "I'll have the Valentine Dinner"). Target = Menu Name.
    3. MODIFY_DRAFT: User changes the current order.
       - Target: The Ingredient Name (e.g., "Wine", "Steak") OR "Style".
       - Quantity: The change amount (+1, -1) or absolute amount.
       - Value: If changing style, the Style Name (Simple, Grand, Deluxe).
    4. CONFIRM_ORDER: User wants to finalize/pay (e.g., "Order now", "That's it").
    5. UNKNOWN: Chit-chat or unclear.

    User Input: "${transcript}"
    
    Output JSON format: { type, target, quantity, value }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: { type: Type.STRING, enum: [
                IntentType.RECOMMEND, 
                IntentType.SELECT_MENU, 
                IntentType.MODIFY_DRAFT, 
                IntentType.CONFIRM_ORDER, 
                IntentType.NAVIGATE, 
                IntentType.UNKNOWN
            ]},
            target: { type: Type.STRING, nullable: true },
            value: { type: Type.STRING, nullable: true },
            quantity: { type: Type.NUMBER, nullable: true }
          }
        }
      }
    });

    if (response.text) {
        return JSON.parse(response.text) as VoiceIntent;
    }
    return { type: IntentType.UNKNOWN };
  } catch (error) {
    console.error("Intent Parsing Error:", error);
    return { type: IntentType.UNKNOWN };
  }
};

// ... (Image generation kept same)
export const generateMenuImage = async (itemName: string, modificationPrompt: string): Promise<string | null> => {
    // ... existing code ...
    return null; 
};
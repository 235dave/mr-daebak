import React, { useState, useEffect, useRef } from 'react';
import { Send, Loader2, Mic, MicOff, Keyboard, Plus, Minus, Check, X, ChefHat } from 'lucide-react';
import { useData } from '../context/DataContext';
import { createChatSession, sendChatMessage, parseVoiceCommand, isGeminiConfigured } from '../services/geminiService';
import { Chat } from '@google/genai';
import { ChatMessage, DraftOrder, IntentType, ServingStyle, MenuItem, ItemCustomization, VoiceIntent } from '../types';
import { RECIPES, INGREDIENTS, INGREDIENT_PRICES, STYLE_PRICES } from '../constants';
import { useNavigate } from 'react-router-dom';

const ChatBot: React.FC = () => {
  const { menu, addToCart, inventory, getMenuStock } = useData();
  const navigate = useNavigate();
  
  // UI State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMode, setInputMode] = useState<'voice' | 'text'>('voice');
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Logic State
  const chatSession = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  
  const [currentDraft, setCurrentDraft] = useState<DraftOrder | null>(null);

  // --- Initialization ---
  useEffect(() => {
    if (!chatSession.current && isGeminiConfigured() && menu.length > 0) {
        const session = createChatSession(menu);
        if (session) {
            chatSession.current = session;
            setMessages([{
                role: 'model', 
                text: '안녕하세요! 미스터 대박입니다. 무엇을 도와드릴까요? (예: "발렌타인 디너 주문해줘", "추천해줘")', 
                type: 'text'
            }]);
        }
    }
  }, [menu]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, currentDraft]);

  // --- Voice Recognition Setup ---
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'ko-KR';

      recognitionRef.current.onstart = () => setIsListening(true);
      recognitionRef.current.onend = () => setIsListening(false);
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleUserMessage(transcript);
      };
    }
  }, []);

  const toggleListening = () => {
    if (isListening) recognitionRef.current?.stop();
    else recognitionRef.current?.start();
  };

  // Helper: Create initial draft
  const initializeDraft = (menuItem: MenuItem): DraftOrder | null => {
      if (getMenuStock(menuItem.id) === 0) {
          setMessages(prev => [...prev, { role: 'model', text: `${menuItem.name}은(는) 현재 품절입니다.`, type: 'text' }]);
          return null;
      }

      const defaultRecipe = RECIPES[menuItem.id] || [];
      const config: any = {};
      
      INGREDIENTS.forEach(ing => {
          const inRecipe = defaultRecipe.find(r => r.ingredientId === ing.id);
          config[ing.id] = { 
              count: inRecipe ? inRecipe.quantity : 0,
              selections: [] 
          };
      });

      let style = ServingStyle.SIMPLE;
      if (menuItem.name.includes('Champagne')) style = ServingStyle.GRAND;

      return {
          menuId: menuItem.id,
          style,
          quantity: 1,
          config
      };
  };

  // Helper: Apply modification logic
  const handleModificationLogic = (draft: DraftOrder, intent: any): string => {
      if (intent.target?.toLowerCase().includes('style') || intent.target?.toLowerCase().includes('스타일') || 
          (intent.value?.includes('Grand') || intent.value?.includes('그랜드')) ||
          (intent.value?.includes('Deluxe') || intent.value?.includes('디럭스')) ||
          (intent.value?.includes('Simple') || intent.value?.includes('심플'))) {
          
          let newStyle = draft.style;
          if (intent.value?.includes('Grand') || intent.value?.includes('그랜드')) newStyle = ServingStyle.GRAND;
          else if (intent.value?.includes('Deluxe') || intent.value?.includes('디럭스')) newStyle = ServingStyle.DELUXE;
          else if (intent.value?.includes('Simple') || intent.value?.includes('심플')) newStyle = ServingStyle.SIMPLE;
          else if (intent.target?.toLowerCase().includes('grand')) newStyle = ServingStyle.GRAND;
          else if (intent.target?.toLowerCase().includes('deluxe')) newStyle = ServingStyle.DELUXE;

          if (newStyle !== draft.style) {
            draft.style = newStyle;
            return `Serving Style을 **${newStyle}**로 변경했습니다.`;
          }
          return "스타일이 변경되지 않았습니다.";
      }

      const targetIng = INGREDIENTS.find(i => 
          intent.target && (i.name.toLowerCase().includes(intent.target.toLowerCase()) || i.id.toLowerCase().includes(intent.target.toLowerCase()))
      );

      if (targetIng) {
          const current = draft.config[targetIng.id];
          const delta = intent.quantity || 1;
          const invItem = inventory.find(i => i.ingredientId === targetIng.id);
          const stock = invItem ? invItem.quantity : 0;
          
          let newCount = current.count + delta;
          let msg = "";
          
          if (newCount < 0) {
            newCount = 0;
            msg = `${targetIng.name} 0개 미만 불가.`;
          } else if (newCount * draft.quantity > stock) {
            newCount = Math.floor(stock / draft.quantity);
            msg = `재고 부족. 최대 ${newCount}개 가능.`;
          } else {
            msg = `${targetIng.name} ${newCount}개로 변경.`;
          }

          draft.config[targetIng.id].count = newCount;
          return msg;
      }
      return "명령을 이해하지 못했습니다.";
  };

  // Helper: Finalize
  const finalizeOrder = (draft: DraftOrder) => {
      const menuItem = menu.find(m => m.id === draft.menuId);
      if (!menuItem) return;

      const customizations: ItemCustomization[] = [];
      const ingredientsPerSet: { id: string; qty: number }[] = [];
      let extraPrice = 0;
      const baseRecipe = RECIPES[menuItem.id] || [];

      Object.entries(draft.config).forEach(([ingId, data]) => {
          if (data.count > 0) {
              const ingName = INGREDIENTS.find(i => i.id === ingId)?.name || ingId;
              customizations.push({ category: ingName, count: data.count, selections: [] }); 
              ingredientsPerSet.push({ id: ingId, qty: data.count });
              
              const baseQty = baseRecipe.find(r => r.ingredientId === ingId)?.quantity || 0;
              if (data.count > baseQty) {
                  extraPrice += (data.count - baseQty) * (INGREDIENT_PRICES[ingId] || 0);
              }
          }
      });

      const result = addToCart({
          menuItem,
          quantity: draft.quantity,
          style: draft.style,
          customizations,
          ingredientsPerSet,
          extraPricePerSet: extraPrice
      });

      if (result.success) {
          setMessages(prev => [...prev, { role: 'model', text: `**${menuItem.name}**가 장바구니에 담겼습니다.`, type: 'text' }]);
          setCurrentDraft(null); 
          setTimeout(() => navigate('/cart'), 1000);
      } else {
          setMessages(prev => [...prev, { role: 'model', text: result.message, type: 'text' }]);
      }
  };

  // **Touch Update Handler (Fixes Issue 1)**
  const handleDraftChangeByTap = (type: 'style' | 'ingredient', targetId: string, value: string | number) => {
    if (!currentDraft || isProcessing) return;
    
    // Create Next Draft
    const nextDraft = { ...currentDraft, config: { ...currentDraft.config } };
    let statusMessage = "";

    if (type === 'style') {
        if (typeof value === 'string' && nextDraft.style !== value) {
            nextDraft.style = value as ServingStyle;
            statusMessage = `스타일이 ${value}로 변경되었습니다.`;
        } else { return; }
    } else if (type === 'ingredient' && typeof value === 'number') {
        const targetIng = INGREDIENTS.find(i => i.id === targetId);
        if (!targetIng) return;
        const current = nextDraft.config[targetId];
        const invItem = inventory.find(i => i.ingredientId === targetId);
        const stock = invItem ? invItem.quantity : 0;

        let newCount = current.count + value;
        if (newCount < 0) newCount = 0;
        else if (newCount * nextDraft.quantity > stock) newCount = Math.floor(stock / nextDraft.quantity);

        if (newCount === current.count) return;
        
        nextDraft.config[targetId] = { ...current, count: newCount };
        statusMessage = `${targetIng.name} ${newCount}개로 변경됨.`;
    }

    // 1. Update State
    setCurrentDraft(nextDraft);

    // 2. Update Message History (Crucial Fix)
    setMessages(prev => {
        const newMsgs = [...prev];
        // Find the latest draft_card to update its payload
        let foundIndex = -1;
        for (let i = newMsgs.length - 1; i >= 0; i--) {
            if (newMsgs[i].type === 'draft_card') {
                foundIndex = i;
                break;
            }
        }
        
        if (foundIndex !== -1) {
            newMsgs[foundIndex] = { ...newMsgs[foundIndex], data: nextDraft };
        }
        // Add feedback
        newMsgs.push({ role: 'model', text: statusMessage, type: 'status_text' });
        return newMsgs;
    });
  };

  // --- Voice/Text Logic ---
  const handleUserMessage = async (text: string) => {
    if (!text.trim()) return;
    setMessages(prev => [...prev, { role: 'user', text }]);
    setInputText('');
    setIsProcessing(true);

    try {
        const intent = await parseVoiceCommand(text, menu);
        let botResponseText = "";
        let nextDraft = currentDraft ? { ...currentDraft, config: {...currentDraft.config} } : null;

        switch (intent.type) {
            case IntentType.RECOMMEND:
                botResponseText = await sendChatMessage(chatSession.current!, text);
                setMessages(prev => [...prev, { role: 'model', text: botResponseText, type: 'recommendation_card' }]);
                setIsProcessing(false);
                return;

            case IntentType.SELECT_MENU:
                const targetMenu = menu.find(m => m.name.toLowerCase().includes(intent.target?.toLowerCase() || ''));
                if (targetMenu) {
                    const newDraft = initializeDraft(targetMenu);
                    if (newDraft) {
                        nextDraft = newDraft;
                        botResponseText = `**${targetMenu.name}**를 선택하셨습니다.`;
                    } else return;
                } else {
                    botResponseText = "메뉴를 찾을 수 없습니다.";
                }
                break;

            case IntentType.MODIFY_DRAFT:
                if (!nextDraft) {
                    botResponseText = "먼저 메뉴를 선택해 주세요.";
                } else {
                    botResponseText = handleModificationLogic(nextDraft, intent);
                }
                break;

            case IntentType.CONFIRM_ORDER:
                if (nextDraft) {
                    finalizeOrder(nextDraft);
                    return;
                } else {
                    botResponseText = "주문할 메뉴가 없습니다.";
                }
                break;

            default:
                botResponseText = await sendChatMessage(chatSession.current!, text);
        }

        if (nextDraft) {
            setCurrentDraft(nextDraft);
            setMessages(prev => [...prev, 
                { role: 'model', text: botResponseText, type: 'text' },
                { role: 'model', text: '', type: 'draft_card', data: nextDraft }
            ]);
        } else {
            setMessages(prev => [...prev, { role: 'model', text: botResponseText, type: 'text' }]);
        }

    } catch (e) {
        console.error(e);
        setMessages(prev => [...prev, { role: 'model', text: "오류 발생", type: 'text' }]);
    } finally {
        setIsProcessing(false);
    }
  };

  // Sub-component for Draft Card
  const DraftOrderCardContent = ({ draft, onFinalize }: { draft: DraftOrder, onFinalize: (d: DraftOrder) => void }) => {
      const mItem = menu.find(m => m.id === draft.menuId);
      if (!mItem) return null;

      let extraTotal = 0;
      const baseRecipe = RECIPES[mItem.id] || [];
      Object.entries(draft.config).forEach(([ingId, data]) => {
          const baseQty = baseRecipe.find(r => r.ingredientId === ingId)?.quantity || 0;
          if (data.count > baseQty) extraTotal += (data.count - baseQty) * (INGREDIENT_PRICES[ingId] || 0);
      });
      const totalPrice = (mItem.price + STYLE_PRICES[draft.style] + extraTotal) * draft.quantity;

      return (
          <div className="w-full bg-white rounded-xl border-2 border-amber-500 shadow-md overflow-hidden mt-2">
              <div className="bg-amber-50 p-3 border-b border-amber-100 flex justify-between items-center">
                  <span className="font-bold text-amber-900">{mItem.name} ({draft.quantity}개)</span>
                  <span className="text-sm font-bold text-stone-800">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="p-3 space-y-3 text-sm">
                  {/* Style */}
                  <div className="flex gap-2 border-b border-stone-100 pb-2">
                      {Object.values(ServingStyle).map(style => (
                          <button key={style} onClick={() => handleDraftChangeByTap('style', 'style', style)}
                            className={`flex-1 py-1 rounded text-xs font-bold ${draft.style === style ? 'bg-amber-500 text-white' : 'bg-stone-100'}`}
                          >{style}</button>
                      ))}
                  </div>
                  {/* Ingredients */}
                  <div className="space-y-1">
                      {Object.entries(draft.config).map(([ingId, data]) => {
                          const name = INGREDIENTS.find(i => i.id === ingId)?.name;
                          if (!name) return null;
                          return (
                              <div key={ingId} className="flex justify-between items-center">
                                  <span>{name}</span>
                                  <div className="flex items-center gap-1">
                                      <button onClick={() => handleDraftChangeByTap('ingredient', ingId, -1)} className="p-1 bg-stone-100 rounded hover:bg-stone-200"><Minus className="w-3 h-3"/></button>
                                      <span className="w-6 text-center font-bold">{data.count}</span>
                                      <button onClick={() => handleDraftChangeByTap('ingredient', ingId, 1)} className="p-1 bg-stone-100 rounded hover:bg-stone-200"><Plus className="w-3 h-3"/></button>
                                  </div>
                              </div>
                          )
                      })}
                  </div>
              </div>
              <div className="p-2 bg-stone-50">
                  <button onClick={() => onFinalize(draft)} className="w-full bg-stone-900 text-white py-2 rounded-lg font-bold flex items-center justify-center gap-1">
                      <Check className="w-4 h-4" /> 주문 확정
                  </button>
              </div>
          </div>
      );
  };

  if (!isGeminiConfigured()) return <div className="p-4 text-center">API Key Error</div>;

  return (
    <div className="flex flex-col h-full bg-stone-50 relative">
        {/* Header */}
        <div className="bg-white border-b p-4 flex justify-between items-center shadow-sm z-10">
            <div className="flex items-center gap-2">
                <ChefHat className="w-6 h-6 text-amber-500" />
                <span className="font-bold text-lg">AI 웨이터</span>
            </div>
            <button onClick={() => setInputMode(inputMode === 'voice' ? 'text' : 'voice')} className="p-2 bg-stone-100 rounded-full">
                {inputMode === 'voice' ? <Keyboard className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
        </div>

        {/* Chat Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-40">
            {messages.map((msg, idx) => (
                <div key={idx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                    {msg.type === 'text' && (
                        <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm shadow-sm ${msg.role === 'user' ? 'bg-amber-500 text-white rounded-br-none' : 'bg-white border border-stone-200 rounded-bl-none'}`}>
                            {msg.text}
                        </div>
                    )}
                    {msg.type === 'status_text' && (
                        <div className="text-xs text-stone-500 mt-1 ml-1">{msg.text}</div>
                    )}
                    {msg.type === 'recommendation_card' && (
                        <div className="mt-2 w-[85%] grid grid-cols-1 gap-2">
                            {menu.slice(0,2).map(m => (
                                <button key={m.id} onClick={() => handleUserMessage(`${m.name} 선택해줘`)} className="bg-white border border-amber-200 p-3 rounded-xl text-left hover:bg-amber-50">
                                    <div className="font-bold text-amber-900">{m.name}</div>
                                    <div className="text-xs text-stone-500">{m.description}</div>
                                </button>
                            ))}
                        </div>
                    )}
                    {msg.type === 'draft_card' && msg.data && (
                        <div className="max-w-[90%] w-full md:w-80">
                            <DraftOrderCardContent draft={msg.data} onFinalize={finalizeOrder} />
                        </div>
                    )}
                </div>
            ))}
            {isProcessing && <div className="flex justify-start"><Loader2 className="w-5 h-5 animate-spin text-amber-500 ml-4" /></div>}
            <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="absolute bottom-0 left-0 w-full bg-white border-t p-6 shadow-lg rounded-t-3xl z-20">
            {inputMode === 'voice' ? (
                <div className="flex flex-col items-center gap-2">
                    <p className="text-sm text-stone-400">{isListening ? "듣고 있습니다..." : "버튼을 누르고 말씀하세요"}</p>
                    <button onClick={toggleListening} className={`w-16 h-16 rounded-full flex items-center justify-center shadow-xl transition-all ${isListening ? 'bg-red-500 animate-pulse text-white' : 'bg-stone-900 text-white'}`}>
                        {isListening ? <Mic className="w-8 h-8" /> : <MicOff className="w-8 h-8" />}
                    </button>
                </div>
            ) : (
                <div className="flex gap-2">
                    <input value={inputText} onChange={e => setInputText(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleUserMessage(inputText)} className="flex-1 bg-stone-100 px-4 py-3 rounded-xl outline-none" placeholder="메시지 입력..." />
                    <button onClick={() => handleUserMessage(inputText)} className="bg-amber-500 text-white p-3 rounded-xl"><Send className="w-5 h-5" /></button>
                </div>
            )}
        </div>
    </div>
  );
};

export default ChatBot;
// MenuOrderModal.tsx
import React, { useState, useEffect } from 'react';
import { MenuItem, ServingStyle, ItemCustomization } from '../types';
import { useData } from '../context/DataContext';
import { 
    STYLE_PRICES, 
    STYLE_DESCRIPTIONS, 
    RECIPES, 
    INGREDIENTS, 
    INGREDIENT_PRICES,
    WINE_TYPES,
    DRESSING_TYPES,
    CHAMPAGNE_TYPES,
    BREAD_TYPES,
    DONENESS_TYPES
} from '../constants';
import { X, Check, MinusCircle, PlusCircle, AlertCircle, Info, Receipt, ChevronDown } from 'lucide-react';

interface MenuOrderModalProps {
  onClose: () => void;
  initialMenuId?: string;
}

// Helper: Map ingredient to option list
const getOptionsForIngredient = (ingId: string) => {
    if (ingId === 'i_wine') return WINE_TYPES;
    if (ingId === 'i_salad') return DRESSING_TYPES;
    if (ingId === 'i_champagne') return CHAMPAGNE_TYPES;
    if (ingId === 'i_bread' || ingId === 'i_baguette') return BREAD_TYPES;
    if (ingId === 'i_steak') return DONENESS_TYPES;
    return null;
};

const MenuOrderModal: React.FC<MenuOrderModalProps> = ({ onClose, initialMenuId }) => {
  const { menu, addToCart, inventory } = useData();
  
  const [selectedMenuId, setSelectedMenuId] = useState<string>(initialMenuId || (menu[0]?.id || ''));
  const [selectedStyle, setSelectedStyle] = useState<ServingStyle>(ServingStyle.SIMPLE);
  const [quantity, setQuantity] = useState(1);

  // Configuration: { [ingredientId]: { count: number, selections: string[] } }
  const [config, setConfig] = useState<Record<string, { count: number, selections: string[] }>>({});

  const selectedMenu = menu.find(m => m.id === selectedMenuId);
  
  // Initialize from Recipe
  useEffect(() => {
      if (!selectedMenu) return;
      
      const defaultRecipe = RECIPES[selectedMenu.id] || [];
      const newConfig: Record<string, any> = {};
      
      // Default items
      defaultRecipe.forEach(item => {
          const opts = getOptionsForIngredient(item.ingredientId);
          // Pre-fill selections
          const selections = Array(item.quantity).fill(opts ? opts[0] : '');
          newConfig[item.ingredientId] = {
              count: item.quantity,
              selections: selections
          };
      });

      // Editable items initialized to 0 if not in recipe
      INGREDIENTS.forEach(ing => {
          if (!newConfig[ing.id]) {
              newConfig[ing.id] = { count: 0, selections: [] };
          }
      });

      setConfig(newConfig);
      setQuantity(1);
      
      // Champagne Restriction
      if (selectedMenu.name.includes('Champagne')) {
          setSelectedStyle(ServingStyle.GRAND);
      } else {
          setSelectedStyle(ServingStyle.SIMPLE);
      }

  }, [selectedMenuId]);

  const updateCount = (ingId: string, delta: number) => {
      setConfig(prev => {
          const current = prev[ingId] || { count: 0, selections: [] };
          const newCount = Math.max(0, current.count + delta);
          
          let newSelections = [...current.selections];
          if (newCount > current.count) {
              const opts = getOptionsForIngredient(ingId);
              newSelections.push(opts ? opts[0] : '');
          } else if (newCount < current.count) {
              newSelections.pop();
          }

          return {
              ...prev,
              [ingId]: { count: newCount, selections: newSelections }
          };
      });
  };

  const updateSelection = (ingId: string, index: number, value: string) => {
      setConfig(prev => {
          const current = prev[ingId];
          const newSelections = [...current.selections];
          newSelections[index] = value;
          return {
              ...prev,
              [ingId]: { ...current, selections: newSelections }
          };
      });
  };

  const handleOrder = () => {
      if (!selectedMenu) return;

      const customizations: ItemCustomization[] = [];
      const ingredientsPerSet: { id: string; qty: number }[] = [];
      let extraPrice = 0;
      const baseRecipe = RECIPES[selectedMenu.id] || [];
      
      Object.entries(config).forEach(([ingId, data]) => {
          if (data.count > 0) {
              const ingName = INGREDIENTS.find(i => i.id === ingId)?.name || ingId;
              
              customizations.push({
                  category: ingName,
                  count: data.count,
                  selections: data.selections.filter(Boolean)
              });

              ingredientsPerSet.push({ id: ingId, qty: data.count });

              // Calc Extra Price
              const baseQty = baseRecipe.find(r => r.ingredientId === ingId)?.quantity || 0;
              if (data.count > baseQty) {
                  const extraCount = data.count - baseQty;
                  extraPrice += (extraCount * (INGREDIENT_PRICES[ingId] || 0));
              }
          }
      });

      addToCart({
          menuItem: selectedMenu,
          quantity,
          style: selectedStyle,
          customizations,
          ingredientsPerSet,
          extraPricePerSet: extraPrice
      });
      
      onClose();
  };

  if (!selectedMenu) return null;

  // Display Calculations
  const isChampagneMenu = selectedMenu.name.includes('Champagne');
  let currentExtraPrice = 0;
  const baseRecipe = RECIPES[selectedMenu.id] || [];
  
  Object.entries(config).forEach(([ingId, data]) => {
      const baseQty = baseRecipe.find(r => r.ingredientId === ingId)?.quantity || 0;
      if (data.count > baseQty) {
          currentExtraPrice += (data.count - baseQty) * (INGREDIENT_PRICES[ingId] || 0);
      }
  });
  
  const totalPrice = (selectedMenu.price + STYLE_PRICES[selectedStyle] + currentExtraPrice) * quantity;

  // Global Inventory Check
  let isStockIssue = false;
  Object.entries(config).forEach(([ingId, data]) => {
      if (data.count > 0) {
          const requiredTotal = data.count * quantity;
          const invItem = inventory.find(i => i.ingredientId === ingId);
          const stock = invItem ? invItem.quantity : 0;
          if (requiredTotal > stock) isStockIssue = true;
      }
  });

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        <div className="bg-stone-900 text-white p-4 flex justify-between items-center shrink-0">
          <h2 className="text-xl font-bold flex items-center gap-2">
            📋 메뉴 상세 설정 (Detailed Options)
          </h2>
          <button onClick={onClose}><X className="w-6 h-6 hover:text-red-400" /></button>
        </div>

        <div className="overflow-y-auto p-6 space-y-8 flex-1 bg-stone-50">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 1. Main Menu Select */}
                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-sm">
                    <label className="block text-sm font-bold text-stone-900 mb-2">메뉴 선택</label>
                    <div className="relative">
                        <select 
                            value={selectedMenuId} 
                            onChange={(e) => setSelectedMenuId(e.target.value)}
                            className="w-full p-3 border border-stone-300 rounded-xl font-medium focus:ring-2 focus:ring-amber-500 outline-none appearance-none bg-transparent"
                        >
                            {menu.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                        </select>
                        <ChevronDown className="absolute right-3 top-3.5 w-5 h-5 text-stone-400 pointer-events-none" />
                    </div>
                    <p className="text-xs text-stone-500 mt-2">{selectedMenu.description}</p>
                </div>
                
                {/* 2. Style Select */}
                <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-sm">
                    <label className="block text-sm font-bold text-stone-900 mb-2">스타일 선택</label>
                    <div className="space-y-2">
                        {Object.values(ServingStyle).map(style => {
                            const disabled = isChampagneMenu && style === ServingStyle.SIMPLE;
                            return (
                                <button
                                    key={style}
                                    onClick={() => !disabled && setSelectedStyle(style)}
                                    disabled={disabled}
                                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                                        disabled ? 'opacity-40 bg-stone-100 cursor-not-allowed' :
                                        selectedStyle === style ? 'border-amber-500 bg-amber-50 shadow-sm' : 'border-stone-200 hover:bg-stone-50'
                                    }`}
                                >
                                    <div className="flex justify-between items-center">
                                        <span className="font-bold text-sm">{style}</span>
                                        <span className="text-xs font-bold text-amber-600">+${STYLE_PRICES[style]}</span>
                                    </div>
                                    <div className="text-[10px] text-stone-500 mt-1">{STYLE_DESCRIPTIONS[style]}</div>
                                </button>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* 3. Detailed Menu Builder */}
            <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
                <label className="text-lg font-bold text-stone-900 mb-4 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-amber-500" /> 상세 구성 (Adjust Options)
                </label>
                
                <div className="space-y-4">
                    {INGREDIENTS.filter(ing => ing.id !== 'i_napkin').map(ing => {
                        const data = config[ing.id] || { count: 0, selections: [] };
                        const optionsList = getOptionsForIngredient(ing.id);
                        const invItem = inventory.find(i => i.ingredientId === ing.id);
                        const stock = invItem ? invItem.quantity : 0;
                        const isMaxed = (data.count + 1) * quantity > stock;

                        return (
                            <div key={ing.id} className="p-4 rounded-xl border border-stone-100 hover:border-stone-300 transition-colors bg-stone-50">
                                <div className="flex justify-between items-center mb-2">
                                    <div>
                                        <div className="font-bold text-stone-800 text-sm">{ing.name}</div>
                                        <div className={`text-[10px] inline-block px-1.5 py-0.5 rounded ${stock < 10 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                            남은 재고: {stock}
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-center gap-3">
                                        <button 
                                            onClick={() => updateCount(ing.id, -1)}
                                            className="w-8 h-8 flex items-center justify-center bg-white border rounded hover:bg-stone-200"
                                        ><MinusCircle className="w-5 h-5 text-stone-400" /></button>
                                        <span className="font-mono font-bold w-6 text-center">{data.count}</span>
                                        <button 
                                            onClick={() => updateCount(ing.id, 1)}
                                            disabled={isMaxed}
                                            className={`w-8 h-8 flex items-center justify-center bg-white border rounded ${isMaxed ? 'opacity-30' : 'hover:bg-stone-200'}`}
                                        ><PlusCircle className="w-5 h-5 text-stone-400" /></button>
                                    </div>
                                </div>

                                {/* Dynamic Dropdowns */}
                                {optionsList && data.count > 0 && (
                                    <div className="mt-3 space-y-2 pl-2 border-l-2 border-amber-200">
                                        {data.selections.map((sel: string, idx: number) => (
                                            <div key={idx} className="flex items-center gap-2">
                                                <span className="text-[10px] text-stone-400 font-mono w-4">{idx+1}.</span>
                                                <select 
                                                    value={sel}
                                                    onChange={(e) => updateSelection(ing.id, idx, e.target.value)}
                                                    className="flex-1 p-1.5 text-xs border rounded bg-white outline-none focus:border-amber-500"
                                                >
                                                    {optionsList.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                                </select>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* 4. Quantity */}
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 flex justify-between items-center">
                <span className="font-bold text-amber-900">세트 수량</span>
                <div className="flex items-center gap-4">
                    <button 
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-10 h-10 rounded-full bg-white border border-amber-200 flex items-center justify-center hover:bg-amber-100"
                    >-</button>
                    <span className="text-2xl font-bold w-12 text-center text-amber-900">{quantity}</span>
                    <button 
                        onClick={() => setQuantity(quantity + 1)}
                        disabled={isStockIssue}
                        className="w-10 h-10 rounded-full bg-white border border-amber-200 flex items-center justify-center hover:bg-amber-100 disabled:opacity-50"
                    >+</button>
                </div>
            </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 bg-white shrink-0">
            <div className="flex justify-between items-center mb-4">
                <div>
                    <span className="text-sm text-stone-500 block">총 예상 금액</span>
                    <span className="text-2xl font-bold text-stone-900">${totalPrice.toFixed(2)}</span>
                </div>
                {isStockIssue && (
                    <div className="text-red-500 font-bold text-xs bg-red-50 px-3 py-2 rounded-lg flex items-center gap-1">
                        <Info className="w-4 h-4" /> 재고 부족
                    </div>
                )}
            </div>
            
            <button 
                onClick={handleOrder}
                disabled={isStockIssue}
                className="w-full bg-stone-900 text-white py-4 rounded-xl font-bold hover:bg-stone-800 transition-colors flex items-center justify-center gap-2 shadow-lg disabled:bg-stone-300 disabled:cursor-not-allowed"
            >
                <Check className="w-5 h-5" />
                장바구니 담기
            </button>
        </div>

      </div>
    </div>
  );
};

export default MenuOrderModal;
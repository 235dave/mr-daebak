export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  STAFF = 'STAFF'
}

export interface UserCoupon {
  id: string;
  code: string;
  name: string;
  discountPercent: number;
  used: boolean;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  completedOrders: number;
  coupons?: UserCoupon[];
}

export enum ServingStyle {
  SIMPLE = 'Simple',
  GRAND = 'Grand',
  DELUXE = 'Deluxe'
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  tags: string[];
  image: string;
}

export interface Ingredient {
  id: string;
  name: string;
  unit: string;
}

export interface InventoryItem {
  ingredientId: string;
  quantity: number;
}

export interface MenuOption {
    id: string;
    name: string;
    price: number;
}

export interface ItemCustomization {
    category: string;
    count: number;
    selections: string[];
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  style: ServingStyle; 
  notes?: string;
  customizations?: ItemCustomization[];
  ingredientsPerSet?: { id: string; qty: number }[]; 
  extraPricePerSet?: number; 
  options?: MenuOption[];       
  removedIngredients?: string[];
}

export interface DeliveryInfo {
  cardNumber: string;
  location: string;
  time: string;
}

export enum OrderStatus {
  CREATED = 'CREATED',
  PREPARING = 'PREPARING',
  COOKING = 'COOKING',
  DELIVERING = 'DELIVERING',
  DELIVERED = 'DELIVERED'
}

export interface StatusHistory {
    status: OrderStatus;
    timestamp: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  items: CartItem[];
  total: number;
  discountAmount?: number;
  finalTotal?: number;
  status: OrderStatus;
  statusHistory: StatusHistory[];
  createdAt: string;
  deliveryInfo: DeliveryInfo;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  description: string;
}

// Updated Intent Types for Chatbot Logic
export enum IntentType {
  RECOMMEND = 'RECOMMEND',         // User asks for suggestion
  SELECT_MENU = 'SELECT_MENU',     // User picks a main menu
  MODIFY_DRAFT = 'MODIFY_DRAFT',   // User adds/removes items or changes style
  CONFIRM_ORDER = 'CONFIRM_ORDER', // User wants to place the order
  NAVIGATE = 'NAVIGATE',
  UNKNOWN = 'UNKNOWN'
}

export interface VoiceIntent {
  type: IntentType;
  target?: string;      // Menu Name or Ingredient Name
  value?: string;       // Style Name or Option Value
  quantity?: number;    // +1, -1, or absolute
}

export interface DraftOrder {
    menuId: string;
    style: ServingStyle;
    quantity: number;
    config: Record<string, { count: number, selections: string[] }>;
}

export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
    type?: 'text' | 'recommendation_card' | 'draft_card';
    data?: any; // To hold DraftOrder state for display
}
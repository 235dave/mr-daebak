// MenuPage.tsx

import React, { useState } from 'react';

import { useData } from '../context/DataContext';

import { PlusCircle, ShoppingBag } from 'lucide-react';

import { MenuItem } from '../types';

import MenuOrderModal from '../components/MenuOrderModal';



const MenuPage: React.FC = () => {

  const { menu, getMenuStock } = useData();

  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);



  return (

    <div className="container mx-auto px-4 py-8">

      <h1 className="text-3xl font-bold text-stone-900 mb-6 flex items-center gap-2">

          <ShoppingBag className="w-8 h-8 text-amber-500" />

          메뉴 (Dinner Menu)

      </h1>

     

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">

        {menu.map((item) => {

          const stock = getMenuStock(item.id);

         

          return (

            <div key={item.id} className="bg-white rounded-xl shadow-sm overflow-hidden border border-stone-100 hover:shadow-md transition-shadow flex flex-col group">

              <div className="h-48 overflow-hidden relative">

                <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />

                {stock === 0 && (

                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm">

                    <span className="text-white font-bold px-4 py-1 border-2 border-white rounded transform -rotate-12">SOLD OUT</span>

                  </div>

                )}

              </div>

             

              <div className="p-5 flex flex-col flex-1">

                <div className="flex justify-between items-start mb-2">

                  <h3 className="font-bold text-lg text-stone-900 leading-tight">{item.name}</h3>

                  <span className="font-semibold text-amber-600 whitespace-nowrap ml-2">${item.price.toFixed(2)}</span>

                </div>

                <p className="text-stone-500 text-sm mb-4 line-clamp-3 flex-1">{item.description}</p>

               

                <div className="flex justify-between items-center mt-4 pt-4 border-t border-stone-50">

                    <span className={`text-xs font-bold px-2 py-1 rounded ${stock > 0 ? 'bg-stone-100 text-stone-500' : 'bg-red-100 text-red-600'}`}>

                        {stock > 0 ? `재고: ${stock}개` : '품절'}

                    </span>

                    <button

                        onClick={() => setSelectedItem(item)}

                        disabled={stock === 0}

                        className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${

                        stock > 0

                            ? 'bg-stone-900 text-white hover:bg-stone-700 shadow-md hover:shadow-lg'

                            : 'bg-stone-200 text-stone-400 cursor-not-allowed'

                        }`}

                    >

                        <PlusCircle className="w-4 h-4" />

                        주문하기

                    </button>

                </div>

              </div>

            </div>

          );

        })}

      </div>



      {/* Detailed Order Modal */}

      {selectedItem && (

          <MenuOrderModal

            onClose={() => setSelectedItem(null)}

            initialMenuId={selectedItem.id}

          />

      )}

    </div>

  );

};



export default MenuPage;
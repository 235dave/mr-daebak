import React from 'react';
import { useData } from '../context/DataContext';
import { OrderStatus } from '../types';
import { Clock, CheckCircle, ChefHat, Truck, Package } from 'lucide-react';

const StaffDashboard: React.FC = () => {
  const { getAllOrders, updateOrderStatus } = useData();
  const orders = getAllOrders();

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.CREATED: return 'bg-stone-100 text-stone-800 border-stone-200';
      case OrderStatus.PREPARING: return 'bg-amber-100 text-amber-800 border-amber-200';
      case OrderStatus.COOKING: return 'bg-orange-100 text-orange-800 border-orange-200';
      case OrderStatus.DELIVERING: return 'bg-blue-100 text-blue-800 border-blue-200';
      case OrderStatus.DELIVERED: return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100';
    }
  };

  const getStatusStep = (status: OrderStatus) => {
      const steps = [OrderStatus.CREATED, OrderStatus.PREPARING, OrderStatus.COOKING, OrderStatus.DELIVERING, OrderStatus.DELIVERED];
      return steps.indexOf(status);
  };

  return (
    <div className="container mx-auto max-w-7xl py-8">
      <h1 className="text-2xl font-bold text-stone-900 mb-6 flex items-center gap-2">
        <ChefHat className="w-8 h-8 text-stone-700" />
        전체 주문 현황 (All Customer Orders)
      </h1>

      <div className="grid grid-cols-1 gap-6">
        {orders.map((order) => {
          const currentStep = getStatusStep(order.status);
          
          return (
          <div key={order.id} className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden flex flex-col md:flex-row">
            {/* Left: Info */}
            <div className="p-6 flex-1 border-b md:border-b-0 md:border-r border-stone-100">
              <div className="flex justify-between items-start mb-4">
                 <div>
                    <span className="inline-block px-2 py-1 bg-stone-100 rounded text-xs font-bold text-stone-500 mb-1">
                        {order.userName}
                    </span>
                    <h3 className="text-lg font-bold text-stone-900">Order #{order.id.slice(-5)}</h3>
                    <div className="text-xs text-stone-400">{new Date(order.createdAt).toLocaleString('ko-KR')}</div>
                 </div>
                 <div className={`px-3 py-1 rounded-full font-bold text-sm border ${getStatusColor(order.status)}`}>
                     {order.status}
                 </div>
              </div>

              <div className="space-y-1 mb-4">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-stone-700">{item.menuItem.name} x{item.quantity}</span>
                    <span className="text-stone-400 font-mono">${(item.menuItem.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="font-bold text-right text-stone-900">
                  Total: ${order.finalTotal ? order.finalTotal.toFixed(2) : order.total.toFixed(2)}
              </div>
            </div>

            {/* Right: Status Control & Timeline */}
            <div className="p-6 w-full md:w-[500px] bg-stone-50 flex flex-col justify-between">
               {/* Timeline */}
               <div className="flex justify-between items-center mb-6 relative">
                   <div className="absolute top-1/2 left-0 w-full h-1 bg-stone-200 -z-0"></div>
                   {[
                       {s: OrderStatus.CREATED, icon: Package, l: '접수'},
                       {s: OrderStatus.PREPARING, icon: Clipboard, l: '준비'}, // Lucide icon check
                       {s: OrderStatus.COOKING, icon: ChefHat, l: '요리'},
                       {s: OrderStatus.DELIVERING, icon: Truck, l: '배달'},
                       {s: OrderStatus.DELIVERED, icon: CheckCircle, l: '완료'},
                   ].map((step, idx) => {
                       const active = idx <= currentStep;
                       const Icon = step.icon; // Simplified
                       return (
                           <div key={idx} className={`relative z-10 flex flex-col items-center gap-1 ${active ? 'text-amber-600' : 'text-stone-400'}`}>
                               <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${active ? 'bg-white border-amber-500' : 'bg-stone-100 border-stone-300'}`}>
                                   <div className={`w-2 h-2 rounded-full ${active ? 'bg-amber-500' : 'bg-stone-300'}`} />
                               </div>
                               <span className="text-[10px] font-bold">{step.l}</span>
                           </div>
                       )
                   })}
               </div>

               {/* Controls */}
               <div className="grid grid-cols-1 gap-2">
                   {order.status === OrderStatus.CREATED && (
                       <button onClick={() => updateOrderStatus(order.id, OrderStatus.PREPARING)} className="w-full py-2 bg-stone-800 text-white rounded hover:bg-stone-900 font-bold text-sm">
                           접수 확인 및 준비 시작 (Start Preparing)
                       </button>
                   )}
                   {order.status === OrderStatus.PREPARING && (
                       <button onClick={() => updateOrderStatus(order.id, OrderStatus.COOKING)} className="w-full py-2 bg-orange-500 text-white rounded hover:bg-orange-600 font-bold text-sm">
                           요리 시작 (Start Cooking)
                       </button>
                   )}
                   {order.status === OrderStatus.COOKING && (
                       <button onClick={() => updateOrderStatus(order.id, OrderStatus.DELIVERING)} className="w-full py-2 bg-blue-500 text-white rounded hover:bg-blue-600 font-bold text-sm">
                           배달 시작 (Start Delivery)
                       </button>
                   )}
                   {order.status === OrderStatus.DELIVERING && (
                       <button onClick={() => updateOrderStatus(order.id, OrderStatus.DELIVERED)} className="w-full py-2 bg-green-600 text-white rounded hover:bg-green-700 font-bold text-sm">
                           배달 완료 처리 (Complete)
                       </button>
                   )}
                   {order.status === OrderStatus.DELIVERED && (
                       <div className="text-center text-xs text-stone-400">모든 과정이 완료되었습니다.</div>
                   )}
               </div>
            </div>
          </div>
        )})}
      </div>
    </div>
  );
};

// Fix Icon Import helper
import { Clipboard } from 'lucide-react';

export default StaffDashboard;
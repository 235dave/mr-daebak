import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { Minus, Plus, AlertTriangle } from 'lucide-react';

const InventoryPage: React.FC = () => {
  const { user } = useAuth();
  const { ingredients, inventory, updateInventory } = useData();

  if (!user || user.role !== UserRole.STAFF) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center p-8 bg-red-50 rounded-xl text-red-800">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">접근 권한 없음</h2>
          <p>이 페이지를 볼 수 있는 권한이 없습니다.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <h1 className="text-3xl font-bold text-stone-900 mb-8">식자재 재고 관리 (Ingredient Inventory)</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ingredients.map((ing) => {
            const stockItem = inventory.find(i => i.ingredientId === ing.id);
            const quantity = stockItem ? stockItem.quantity : 0;
            
            return (
                <div key={ing.id} className="bg-white p-6 rounded-xl shadow-sm border border-stone-200 flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <h3 className="font-bold text-lg text-stone-800">{ing.name}</h3>
                            <span className="text-xs text-stone-400">Unit: {ing.unit}</span>
                        </div>
                        <div className={`px-3 py-1 rounded-full font-bold text-sm ${
                            quantity === 0 ? 'bg-red-100 text-red-600' : 
                            quantity < 10 ? 'bg-amber-100 text-amber-600' : 'bg-green-100 text-green-600'
                        }`}>
                            {quantity} {ing.unit}
                        </div>
                    </div>

                    <div className="flex items-center justify-between bg-stone-50 p-2 rounded-lg">
                        <span className="text-sm font-medium text-stone-600">수량 조절</span>
                        <div className="flex items-center gap-3">
                            <button 
                                onClick={() => updateInventory(ing.id, -1)}
                                disabled={quantity <= 0}
                                className={`w-8 h-8 flex items-center justify-center border border-stone-300 rounded transition-colors ${
                                    quantity <= 0 
                                    ? 'bg-stone-100 text-stone-300 cursor-not-allowed' 
                                    : 'bg-white text-stone-600 hover:bg-red-50 hover:border-red-200'
                                }`}
                            >
                                <Minus className="w-4 h-4" />
                            </button>
                            <span className="font-mono font-bold w-8 text-center">{quantity}</span>
                            <button 
                                onClick={() => updateInventory(ing.id, 1)}
                                className="w-8 h-8 flex items-center justify-center bg-white border border-stone-300 rounded hover:bg-green-50 hover:border-green-200 text-stone-600"
                            >
                                <Plus className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                </div>
            );
        })}
      </div>
    </div>
  );
};

export default InventoryPage;
import React from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Package, CheckCircle } from 'lucide-react';
import { OrderStatus } from '../types';

const OrdersPage: React.FC = () => {
  const { getUserOrders } = useData();
  const { user } = useAuth();
  const orders = getUserOrders();

  if (!user) return <div>로그인이 필요합니다.</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl font-bold text-stone-900 mb-6">내 주문 내역</h1>
      
      <div className="space-y-6">
        {orders.map((order) => (
          <div key={order.id} className="bg-white border border-stone-200 rounded-xl p-6 shadow-sm">
             <div className="flex justify-between items-start mb-4 pb-4 border-b border-stone-100">
                 <div>
                     <span className="text-xs font-bold text-stone-400">ORDER #{order.id.slice(-5)}</span>
                     <div className="text-sm text-stone-500">{new Date(order.createdAt).toLocaleString('ko-KR')}</div>
                 </div>
                 <div className="text-right">
                     <div className="font-bold text-lg">${(order.finalTotal || order.total).toFixed(2)}</div>
                     <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold ${order.status === OrderStatus.DELIVERED ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                         {order.status}
                     </span>
                 </div>
             </div>

             {/* Items */}
             <div className="space-y-2 mb-6">
                 {order.items.map((item, idx) => (
                     <div key={idx} className="flex justify-between text-sm text-stone-700">
                         <span>{item.menuItem.name} ({item.style}) x{item.quantity}</span>
                     </div>
                 ))}
             </div>

             {/* Detailed Status History Timeline */}
             <div className="bg-stone-50 rounded-lg p-4">
                 <h4 className="text-xs font-bold text-stone-500 mb-3 uppercase">배달 진행 상황</h4>
                 <div className="space-y-3 relative">
                     <div className="absolute left-[5px] top-2 bottom-2 w-0.5 bg-stone-200"></div>
                     {(order.statusHistory || []).map((hist, hIdx) => (
                         <div key={hIdx} className="relative pl-6 flex justify-between items-center text-sm">
                             <div className="absolute left-0 top-1.5 w-3 h-3 rounded-full bg-amber-500 border-2 border-white shadow-sm"></div>
                             <span className="font-bold text-stone-800">{hist.status}</span>
                             <span className="text-stone-400 text-xs font-mono">
                                 {new Date(hist.timestamp).toLocaleTimeString('ko-KR')}
                             </span>
                         </div>
                     ))}
                 </div>
             </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrdersPage;
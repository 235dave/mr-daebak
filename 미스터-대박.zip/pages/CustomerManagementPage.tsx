
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { User, Ticket, Search, UserCheck } from 'lucide-react';

const CustomerManagementPage: React.FC = () => {
  const { customers, issueCoupon } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<string | null>(null);

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleGiveCoupon = async (discount: number) => {
      if (!selectedUser) return;
      if (window.confirm(`선택한 고객에게 ${discount}% 쿠폰을 발급하시겠습니까?`)) {
          await issueCoupon(selectedUser, discount);
          alert('쿠폰이 발급되었습니다.');
          setSelectedUser(null);
      }
  };

  return (
    <div className="container mx-auto py-8 flex flex-col min-h-screen">
      <h1 className="text-2xl font-bold text-stone-900 mb-6 flex items-center gap-2">
        <UserCheck className="w-8 h-8" /> 고객 관리 및 쿠폰 발급
      </h1>

      <div className="bg-white rounded-xl shadow-sm border border-stone-200">
         {/* Toolbar */}
         <div className="p-4 border-b border-stone-100 flex gap-4 bg-stone-50">
             <div className="relative flex-1 max-w-md">
                 <Search className="absolute left-3 top-2.5 w-5 h-5 text-stone-400" />
                 <input 
                    type="text" 
                    placeholder="이름 또는 이메일 검색..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full pl-10 px-4 py-2 rounded-lg border border-stone-300 outline-none focus:ring-2 focus:ring-amber-500"
                 />
             </div>
         </div>

         <table className="w-full text-left">
             <thead className="bg-stone-100 text-stone-600 font-bold text-sm">
                 <tr>
                     <th className="p-4">고객명</th>
                     <th className="p-4">이메일</th>
                     <th className="p-4 text-center">총 주문 횟수</th>
                     <th className="p-4 text-right">관리</th>
                 </tr>
             </thead>
             <tbody className="divide-y divide-stone-100">
                 {filteredCustomers.map(user => (
                     <tr key={user.id} className="hover:bg-amber-50 transition-colors">
                         <td className="p-4 font-medium flex items-center gap-2">
                             <div className="w-8 h-8 bg-stone-200 rounded-full flex items-center justify-center">
                                 <User className="w-4 h-4 text-stone-500" />
                             </div>
                             {user.name}
                         </td>
                         <td className="p-4 text-stone-500">{user.email}</td>
                         <td className="p-4 text-center">
                             <span className="inline-block px-3 py-1 bg-stone-100 rounded-full text-stone-800 font-bold text-xs">
                                 {user.completedOrders}회
                             </span>
                         </td>
                         <td className="p-4 text-right">
                             <div className="relative inline-block">
                                 <button 
                                    onClick={() => setSelectedUser(selectedUser === user.id ? null : user.id)}
                                    className={`px-3 py-1.5 rounded-lg text-sm font-bold flex items-center gap-1 ml-auto transition-colors ${
                                        selectedUser === user.id 
                                        ? 'bg-stone-800 text-white shadow-inner' 
                                        : 'bg-amber-500 text-white hover:bg-amber-600 shadow-sm'
                                    }`}
                                 >
                                     <Ticket className="w-4 h-4" /> 
                                     {selectedUser === user.id ? '발급 중...' : '쿠폰 발급'}
                                 </button>
                                 
                                 {selectedUser === user.id && (
                                     <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-xl shadow-xl border border-stone-200 z-20 overflow-hidden animate-in fade-in zoom-in-95 duration-200 p-3">
                                         <div className="text-xs font-bold text-stone-500 mb-2 px-1">할인율 선택 (간편 발급)</div>
                                         <div className="grid grid-cols-4 gap-2">
                                             {[5, 10, 15, 30].map(percent => (
                                                 <button 
                                                    key={percent}
                                                    onClick={() => handleGiveCoupon(percent)} 
                                                    className={`py-2 rounded-lg font-bold text-sm transition-transform hover:scale-105 ${
                                                        percent === 30 
                                                        ? 'bg-red-50 text-red-600 hover:bg-red-100 border border-red-200' 
                                                        : 'bg-stone-50 text-stone-700 hover:bg-amber-50 hover:text-amber-700 border border-stone-200'
                                                    }`}
                                                 >
                                                     {percent}%
                                                 </button>
                                             ))}
                                         </div>
                                         <button onClick={() => setSelectedUser(null)} className="w-full mt-3 py-1 text-xs text-stone-400 hover:text-stone-600">
                                             취소
                                         </button>
                                     </div>
                                 )}
                             </div>
                         </td>
                     </tr>
                 ))}
                 {filteredCustomers.length === 0 && (
                     <tr>
                         <td colSpan={4} className="p-8 text-center text-stone-400">고객 데이터가 없습니다.</td>
                     </tr>
                 )}
             </tbody>
         </table>
      </div>
    </div>
  );
};

export default CustomerManagementPage;

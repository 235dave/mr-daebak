import React from 'react';
import ChatBot from '../components/ChatBot';

const CustomerHome: React.FC = () => {
  return (
    <div className="h-[calc(100vh-64px)] bg-stone-50 p-4 md:p-6">
      <div className="max-w-4xl mx-auto h-full flex flex-col shadow-2xl rounded-3xl overflow-hidden border border-stone-200 bg-white">
          <ChatBot />
      </div>
    </div>
  );
};

export default CustomerHome;
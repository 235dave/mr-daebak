import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Trash2, ShoppingBag, CreditCard, MapPin, Clock, Ticket } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { STYLE_PRICES } from '../constants';
import { UserCoupon } from '../types';

const CartPage: React.FC = () => {
  const { cart, removeFromCart, placeOrder, clearCart } = useData();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [cardNumber, setCardNumber] = useState('');
  const [location, setLocation] = useState('');
  const [time, setTime] = useState('');
  const [selectedCouponId, setSelectedCouponId] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Calculate Totals
  const subtotal = cart.reduce((sum, item) => {
      const base = item.menuItem.price;
      const style = STYLE_PRICES[item.style];
      const extra = item.extraPricePerSet || 0;
      return sum + ((base + style + extra) * item.quantity);
  }, 0);

  // Coupon Logic
  const selectedCoupon = user?.coupons?.find(c => c.id === selectedCouponId);
  const discountAmount = selectedCoupon ? subtotal * (selectedCoupon.discountPercent / 100) : 0;
  const total = subtotal - discountAmount;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardNumber || !location || !time) return;

    setIsSubmitting(true);
    await placeOrder({ cardNumber, location, time }, selectedCoupon);
    setTimeout(() => {
        setIsSubmitting(false);
        navigate('/orders');
    }, 1000);
  };

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag className="w-10 h-10 text-stone-400" />
        </div>
        <h2 className="text-2xl font-bold text-stone-900 mb-2">장바구니가 비었습니다</h2>
        <Link to="/" className="inline-block bg-amber-500 text-white px-8 py-3 rounded-lg font-semibold mt-4">메뉴 보러가기</Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <h1 className="text-3xl font-bold text-stone-900 mb-8">주문서 (Checkout)</h1>
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Cart Items */}
        <div className="flex-1 space-y-4">
          {cart.map((item, idx) => (
            <div key={idx} className="flex gap-4 bg-white p-4 rounded-xl shadow-sm border border-stone-100">
              <img src={item.menuItem.image} className="w-20 h-20 object-cover rounded-lg" />
              <div className="flex-1">
                <h3 className="font-bold">{item.menuItem.name}</h3>
                <div className="text-xs text-stone-500">{item.style} Style</div>
                {/* Display Detailed Customizations */}
                {item.customizations && item.customizations.length > 0 ? (
                    <div className="mt-2 text-xs text-stone-500 space-y-1 bg-stone-50 p-2 rounded">
                        {item.customizations.map((cust, cIdx) => (
                            <div key={cIdx}>
                                <span className="font-bold">{cust.category}:</span> {cust.count}개
                                {cust.selections.length > 0 && (
                                    <span className="text-stone-400"> ({cust.selections.join(', ')})</span>
                                )}
                            </div>
                        ))}
                    </div>
                ) : item.options && item.options.length > 0 && (
                    // Legacy options fallback
                    <div className="text-xs text-stone-400 mt-1">
                        + {item.options.map(o => o.name).join(', ')}
                    </div>
                )}
              </div>
              <div className="text-right">
                  <div className="font-bold">${((item.menuItem.price + STYLE_PRICES[item.style] + (item.extraPricePerSet || 0)) * item.quantity).toFixed(2)}</div>
                  <div className="text-xs text-stone-400">x {item.quantity} 세트</div>
              </div>
              <button onClick={() => removeFromCart(idx)} className="p-2 hover:bg-red-50 rounded-full transition-colors group">
                  <Trash2 className="w-5 h-5 text-stone-400 group-hover:text-red-500" />
              </button>
            </div>
          ))}
        </div>

        {/* Payment Form */}
        <div className="w-full lg:w-96 bg-white p-6 rounded-xl shadow-lg border border-stone-100 h-fit sticky top-24">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5" /> 결제 정보
            </h3>
            <form onSubmit={handleCheckout} className="space-y-4">
                <input required placeholder="주소" value={location} onChange={e => setLocation(e.target.value)} className="w-full p-2 border rounded" />
                <input required type="time" value={time} onChange={e => setTime(e.target.value)} className="w-full p-2 border rounded" />
                <input required placeholder="카드 번호" value={cardNumber} onChange={e => setCardNumber(e.target.value)} className="w-full p-2 border rounded" />
                
                {/* Coupon Select */}
                {user?.coupons && user.coupons.length > 0 && (
                    <div className="pt-4 border-t border-stone-100">
                        <label className="block text-sm font-bold text-stone-700 mb-2 flex items-center gap-2">
                            <Ticket className="w-4 h-4 text-amber-500" /> 쿠폰 적용
                        </label>
                        <select 
                            className="w-full p-2 border border-amber-200 rounded bg-amber-50 text-sm"
                            value={selectedCouponId}
                            onChange={(e) => setSelectedCouponId(e.target.value)}
                        >
                            <option value="">쿠폰 선택 안함</option>
                            {user.coupons.map(c => (
                                <option key={c.id} value={c.id}>
                                    {c.name} (-{c.discountPercent}%)
                                </option>
                            ))}
                        </select>
                    </div>
                )}

                <div className="border-t border-stone-200 pt-4 space-y-2">
                    <div className="flex justify-between"><span>상품 금액</span><span>${subtotal.toFixed(2)}</span></div>
                    {discountAmount > 0 && (
                        <div className="flex justify-between text-green-600 font-bold">
                            <span>할인 금액</span><span>-${discountAmount.toFixed(2)}</span>
                        </div>
                    )}
                    <div className="flex justify-between text-xl font-bold pt-2 border-t"><span>총 결제</span><span>${total.toFixed(2)}</span></div>
                </div>

                <button disabled={isSubmitting} className="w-full bg-stone-900 text-white py-3 rounded font-bold hover:bg-stone-800">
                    {isSubmitting ? '처리 중...' : '결제하기'}
                </button>
            </form>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
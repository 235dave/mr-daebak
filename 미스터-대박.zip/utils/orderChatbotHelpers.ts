// ../utils/orderChatbotHelpers.ts
import { DraftOrder, MenuItem, IntentType, ServingStyle, VoiceIntent, ItemCustomization, ChatMessage, InventoryItem } from '../types';
import { RECIPES, INGREDIENTS, INGREDIENT_PRICES, STYLE_PRICES } from '../constants';
import { NavigateFunction } from 'react-router-dom';
import { AddToCartSignature } from '../context/DataContext';

// MenuOrderModal.tsx에서 가져옴
const getOptionsForIngredient = (ingId: string) => {
    if (ingId === 'i_wine') return ['Red Wine', 'White Wine', 'Rose Wine'];
    if (ingId === 'i_salad') return ['Balsamic', 'Ranch', 'Caesar'];
    if (ingId === 'i_champagne') return ['Brut', 'Demi-Sec', 'Extra Brut'];
    if (ingId === 'i_bread' || ingId === 'i_baguette') return ['Sourdough', 'Whole Wheat', 'Rye'];
    if (ingId === 'i_steak') return ['Rare', 'Medium-Rare', 'Medium', 'Medium-Well', 'Well-Done'];
    return null;
};

// Helper: Create initial draft from Main Menu default recipe
export const initializeDraftLogic = (menuItem: MenuItem, recipes: typeof RECIPES, ingredients: typeof INGREDIENTS): DraftOrder => {
    const defaultRecipe = recipes[menuItem.id] || [];
    const config: any = {};

    // Init ingredients
    ingredients.forEach(ing => {
        const inRecipe = defaultRecipe.find(r => r.ingredientId === ing.id);
        const count = inRecipe ? inRecipe.quantity : 0;
        const opts = getOptionsForIngredient(ing.id);
        const selections = Array(count).fill(opts ? opts[0] : '');

        config[ing.id] = { 
            count: count,
            selections: selections 
        };
    });

    // Style Default
    let style = ServingStyle.SIMPLE;
    if (menuItem.name.includes('Champagne')) style = ServingStyle.GRAND;

    return {
        menuId: menuItem.id,
        style,
        quantity: 1,
        config
    };
};

// Helper: Apply modification to draft
export const handleModificationLogic = (draft: DraftOrder, intent: VoiceIntent, ingredients: typeof INGREDIENTS, inventory: InventoryItem[]) => {
    // 1. Quantity Change
    if (intent.type === IntentType.MODIFY_DRAFT && intent.target === 'quantity') {
        const delta = intent.quantity || 1;
        draft.quantity = Math.max(1, draft.quantity + delta);
        return;
    }

    // 2. Style Change
    if (intent.target?.toLowerCase().includes('style') || intent.target?.toLowerCase().includes('스타일') || intent.value) {
        let newStyle: ServingStyle = draft.style;
        if (intent.value?.includes('Grand') || intent.value?.includes('그랜드')) newStyle = ServingStyle.GRAND;
        else if (intent.value?.includes('Deluxe') || intent.value?.includes('디럭스')) newStyle = ServingStyle.DELUXE;
        else newStyle = ServingStyle.SIMPLE;
        
        const isChampagneMenu = draft.menuId.includes('m_champagne'); // 메뉴 ID 확인 필요
        if (!(isChampagneMenu && newStyle === ServingStyle.SIMPLE)) {
            draft.style = newStyle;
        }
        return;
    }

    // 3. Ingredient Change (Fuzzy Match)
    const targetIng = ingredients.find(i => 
        intent.target && (i.name.includes(intent.target) || i.id.includes(intent.target))
    );

    if (targetIng) {
        const current = draft.config[targetIng.id] || { count: 0, selections: [] };
        const delta = intent.quantity || 1; // Default +1 if "Add wine"

        // Check Inventory 
        const invItem = inventory.find(i => i.ingredientId === targetIng.id);
        const stock = invItem ? invItem.quantity : 0;
    
        // Apply change
        let newCount = current.count + delta;
        if (newCount < 0) newCount = 0;

        // Stock constraint
        if (newCount * draft.quantity > stock) {
            newCount = Math.floor(stock / draft.quantity); // Clamp to max possible
        }

        // Update selections array size
        let newSelections = [...current.selections];
        if (newCount > current.count) {
            const opts = getOptionsForIngredient(targetIng.id);
            newSelections.push(opts ? opts[0] : '');
        } else if (newCount < current.count) {
            newSelections.pop();
        }

        draft.config[targetIng.id] = { count: newCount, selections: newSelections };
    }
};

// Helper: Finalize Order (MenuOrderModal.tsx의 handleOrder 로직)
export const finalizeOrderLogic = (
    draft: DraftOrder,
    menu: MenuItem[],
    addToCart: AddToCartSignature,
    recipes: typeof RECIPES,
    ingredients: typeof INGREDIENTS,
    ingredientPrices: typeof INGREDIENT_PRICES,
    stylePrices: typeof STYLE_PRICES,
    navigate: NavigateFunction,
    setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
    setCurrentDraft: React.Dispatch<React.SetStateAction<DraftOrder | null>>
) => {
    const menuItem = menu.find(m => m.id === draft.menuId);
    if (!menuItem) return;

    const customizations: ItemCustomization[] = [];
    const ingredientsPerSet: { id: string; qty: number }[] = [];
    let extraPrice = 0;
    const baseRecipe = recipes[menuItem.id] || [];

    Object.entries(draft.config).forEach(([ingId, data]) => {
        if (data.count > 0) {
            const ingName = ingredients.find(i => i.id === ingId)?.name || ingId;
            customizations.push({
                category: ingName,
                count: data.count,
                selections: data.selections.filter(Boolean)
            });
            ingredientsPerSet.push({ id: ingId, qty: data.count });
            
            const baseQty = baseRecipe.find(r => r.ingredientId === ingId)?.quantity || 0;
            if (data.count > baseQty) {
                extraPrice += (data.count - baseQty) * (ingredientPrices[ingId] || 0);
            }
        }
    });

    const result = addToCart({
        menuItem,
        quantity: draft.quantity,
        style: draft.style,
        customizations,
        ingredientsPerSet,
        extraPricePerSet: extraPrice
    });

    if (result.success) {
        setMessages(prev => [...prev, { role: 'model', text: `**${menuItem.name}** ${draft.quantity}개 주문이 장바구니에 담겼습니다. 결제 페이지로 이동합니다.`, type: 'text' }]);
        setCurrentDraft(null); // 주문 완료 후 초기화
        setTimeout(() => navigate('/cart'), 1500);
    } else {
        setMessages(prev => [...prev, { role: 'model', text: `[재고 오류] ${result.message}\n주문이 취소되었습니다. 다시 시도해 주세요.`, type: 'text' }]);
    }
};